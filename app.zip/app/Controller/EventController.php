<?php

declare(strict_types=1);
/**
 * 事件
 */
namespace App\Controller;
use App\Service\UserService;
use Hyperf\Di\Annotation\Inject;
class EventController extends AbstractController
{
    #[Inject]
    protected UserService $userService;

    public function index()
    {
        $user = $this->request->input('user', 'Hyperf');
        $method = $this->request->getMethod();
        $result=$this->userService->register();
        return [
            'method' => $method,
            'result' => $result,
            'message' => "Hello {$user}.",
        ];
    }
}
